/* jshint node:true */

module.exports = {
  publish: true
};
